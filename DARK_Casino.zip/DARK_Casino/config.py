BOT_TOKEN = "7070567639:AAG69-iAuDxh2Ybe0YvhG7lAA8R0kahfPq0" 
CRYPTOBOT_TOKEN = "163256:AAunRiHYRgz4KdncccpeMB4n1lcQMzzG9ch" 
CHANNEL_ID = -1002096650731
LOGS_ID = -1002130629935
ALL_ADMINS = [1467486022] 
ADMIN_IDS = "1467486022" 
 
NAME_PROJECT = "DARK Casino" 
 
BOT_LINK = "http://t.me/DarkDCasino_bot" 
pinned_link = "http://t.me/send?start=IVskdtpQhYR5" 
rules_link = "https://t.me/RuleKUMELOVDICE/2" 
rule_link = "https://t.me/RuleKUMELOVDICE" 
support_link = "https://t.me/Kumelov" 
casino_link = "https://t.me/+47WRkHKJlKk0NmIy" 
  
win_1_photo = "https://imgur.com/a/4aIoKCH" 
win_2_photo = "https://imgur.com/a/08Gz9DL" 
win_3_photo = "https://imgur.com/a/oda3g4N" 
win_4_photo = "https://imgur.com/a/IQee1Tx" 
win_5_photo = "https://imgur.com/a/igIHk6H" 
win_6_photo = "https://imgur.com/a/Hbio46F" 
win_7_photo = "https://imgur.com/a/2DZY5ha"
 

ref_procent = 5 
 
api_id = 28449234
api_hash = "8bf2b84215314bea7d9bfc14f674716b" 
 
DATABASE_PATH = "alt_script.db" #не трогать 
 
games_list = { 
    'победа1': 'one', 
    'победа2': 'two', 
    'ничья': 'three', 
    'меньше': 'four_one', 
    'больше': 'four_two', 
    'чёт': 'five_one', 
    'чётное:': 'five_one', 
    'чет': 'five_one', 
    'чет': 'five_one', 
    'нечёт': 'five_two', 
    'нечётное': 'five_two', 
    'нечет': 'five_two', 
    'нечетное': 'five_two' 
 
} 
 
pay_x_amount = { 
    "one": 1.8, 
    "two": 1.8, 
    "three": 3, 
    "four": 1.7, 
    "five": 1.7 
}
