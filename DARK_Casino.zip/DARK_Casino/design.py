def new_bid(name, amount, coment):
    return f"""
<b>💸 Новая ставка!</b>

👤 Игрок: <b>{name}</b>

💰 Депозит: <b>{amount}$</b>

💎 Исход: <b>{coment}</b>
    """